//package vn.mobiistar.testversion;
//
//import android.os.AsyncTask;
//import android.os.Bundle;
//import android.support.v7.app.AppCompatActivity;
//import android.util.Log;
//import android.util.SparseArray;
//import android.view.SurfaceHolder;
//import android.view.SurfaceView;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.firebase.client.DataSnapshot;
//import com.firebase.client.Firebase;
//import com.firebase.client.FirebaseError;
//import com.firebase.client.ValueEventListener;
////import com.google.android.gms.vision.CameraSource;
////import com.google.android.gms.vision.Detector;
////import com.google.android.gms.vision.barcode.Barcode;
////import com.google.android.gms.vision.barcode.BarcodeDetector;
//
//import org.json.JSONObject;
//
//import java.io.BufferedReader;
//import java.io.BufferedWriter;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.io.OutputStream;
//import java.io.OutputStreamWriter;
//import java.net.HttpURLConnection;
//import java.net.URL;
//import java.net.URLEncoder;
//import java.util.ArrayList;
//import java.util.Iterator;
//
//import javax.net.ssl.HttpsURLConnection;
//
//public class MainActivity2 extends AppCompatActivity {
//
//    SurfaceView cameraView;
//    TextView barcodeInfo;
////    BarcodeDetector barcodeDetector;
////    CameraSource cameraSource;
//    boolean takeQR = false;
//
//    // them vao test firebase
//    private EditText editTextName;
//    private EditText editTextAddress;
//    private TextView textViewPersons;
//    private Button buttonSave;
//    private static final String TAG = "MyActivity";
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_main);
////        setContentView(R.layout.linear);
////        new SendPostRequest().execute();
////        getQRCode();
//
//        /*if(takeQR == true){
//            setContentView(R.layout.activity_main);
//        } else{
//            setContentView(R.layout.choose_feature);
//            Button takeQRCode = (Button) findViewById(R.id.take_qrcode);
//
//            takeQRCode.setOnClickListener(new View.OnClickListener(){
//                public void onClick(View v){
//                    setContentView(R.layout.take_qrcode);
//                }
//            });
//        }*/
//
//
//        Firebase.setAndroidContext(this);
//        Firebase myFirebaseRef = new Firebase("https://testfcm-7f1a7.firebaseio.com/promotions");
//        myFirebaseRef.child("mobiistarprimexgrand").setValue("Do you have data? You'll love Firebase.");
//        Toast.makeText(getApplicationContext(), "Successfully...", Toast.LENGTH_LONG).show();
//
//        ValueEventListener postListener = new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                // Get Post object and use the values to update the UI
//                Log.e(TAG, dataSnapshot.toString());
////                Promotion promotion = dataSnapshot.getValue(Promotion.class);
////                Log.e(TAG, promotion.toString());
//                // ...
//            }
//
//            @Override
//            public void onCancelled(FirebaseError databaseError) {
//                // Getting Post failed, log a message
//                Log.w(TAG, "loadPost:onCancelled", databaseError.toException());
//                // ...
//            }
//        };
//        myFirebaseRef.addValueEventListener(postListener);
//
//        setContentView(R.layout.firebase);
//
//    }
//
//    public class Promotion {
//
//        public Integer key;
//        public String model;
//        public ArrayList photo;
//        public ArrayList video;
//
//        public Promotion() {
//            // Default constructor required for calls to DataSnapshot.getValue(Post.class)
//        }
//
//        public Promotion(Integer key, String model, ArrayList photo, ArrayList video) {
//            this.key = key;
//            this.model = model;
//            this.photo = photo;
//            this.video = video;
//        }
//
//    }
//
//    public class SendPostRequest extends AsyncTask<String, Void, String> {
//
//        protected void onPreExecute(){}
//
//        protected String doInBackground(String... arg0) {
//
//            try {
//
//                URL url = new URL("http://192.168.105.10/coupon-tools/index.php/api/versions/get_version"); // here is your URL path
//
//                JSONObject postDataParams = new JSONObject();
//                postDataParams.put("username", "mobiistar");
//                postDataParams.put("password", "mobiistar");
//                postDataParams.put("phone_imei", "123456789");
//                postDataParams.put("model", "1");
//                postDataParams.put("version", "1.0.0");
//                Log.e("params", postDataParams.toString());
//
//                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//                conn.setReadTimeout(15000 /* milliseconds */);
//                conn.setConnectTimeout(15000 /* milliseconds */);
//                conn.setRequestMethod("GET");
//                conn.setDoInput(true);
//                conn.setDoOutput(true);
//
//                String request = getPostDataString(postDataParams);
//                TextView hello = (TextView)findViewById(R.id.code_info);
//                System.out.print(request);
//
//                OutputStream os = conn.getOutputStream();
//                BufferedWriter writer = new BufferedWriter(
//                        new OutputStreamWriter(os, "UTF-8"));
//                writer.write(request);
//
//                writer.flush();
//                writer.close();
//                os.close();
//
//                int responseCode=conn.getResponseCode();
//
//                if (responseCode == HttpsURLConnection.HTTP_OK) {
//
//                    BufferedReader in=new BufferedReader(new
//                            InputStreamReader(
//                            conn.getInputStream()));
//
//                    StringBuffer sb = new StringBuffer("");
//                    String line="";
//
//                    while((line = in.readLine()) != null) {
//
//                        sb.append(line);
//                        break;
//                    }
//
//                    in.close();
//                    return sb.toString();
//
//                }
//                else {
//                    return new String("false : "+responseCode);
//                }
//            }
//            catch(Exception e){
//                return new String("Exception: " + e.getMessage());
//            }
//
//        }
//
//        @Override
//        protected void onPostExecute(String result) {
//            Log.d("123", result);
//            Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
//            TextView hello = (TextView)findViewById(R.id.code_info);
//            hello.setText(result);
//        }
//    }
//
//    public String getPostDataString(JSONObject params) throws Exception {
//
//        StringBuilder result = new StringBuilder();
//        boolean first = true;
//
//        Iterator<String> itr = params.keys();
//
//        while(itr.hasNext()){
//
//            String key= itr.next();
//            Object value = params.get(key);
//
//            if (first)
//                first = false;
//            else
//                result.append("&");
//
//            result.append(URLEncoder.encode(key, "UTF-8"));
//            result.append("=");
//            result.append(URLEncoder.encode(value.toString(), "UTF-8"));
//
//        }
//        return params.toString();
////        return result.toString();
//    }
//
//    public void getQRCode(){
//        cameraView = (SurfaceView)findViewById(R.id.camera_view);
//        barcodeInfo = (TextView)findViewById(R.id.code_info);
//        barcodeDetector = new BarcodeDetector.Builder(this)
//                .setBarcodeFormats(Barcode.QR_CODE)
//                .build();
//
//        cameraSource = new CameraSource
//                .Builder(this, barcodeDetector)
//                .setRequestedPreviewSize(640, 480)
//                .build();
//
//        cameraView.getHolder().addCallback(new SurfaceHolder.Callback() {
//            @Override
//            public void surfaceCreated(SurfaceHolder holder) {
//                try {
//                    cameraSource.start(cameraView.getHolder());
//                } catch (IOException ie) {
//                    Log.e("CAMERA SOURCE", ie.getMessage());
//                }
//            }
//
//            @Override
//            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
//            }
//
//            @Override
//            public void surfaceDestroyed(SurfaceHolder holder) {
//                cameraSource.stop();
//            }
//        });
//
//        barcodeDetector.setProcessor(new Detector.Processor<Barcode>() {
//            @Override
//            public void release() {
//            }
//
//            @Override
//            public void receiveDetections(Detector.Detections<Barcode> detections) {
//                final SparseArray<Barcode> barcodes = detections.getDetectedItems();
//
//                if (barcodes.size() != 0) {
//                    barcodeInfo.post(new Runnable() {    // Use the post method of the TextView
//                        public void run() {
//                        barcodeInfo.setText(    // Update the TextView
//                            barcodes.valueAt(0).displayValue
//                        );
//                        }
//                    });
//                }
//            }
//        });
//    }
//
//}
