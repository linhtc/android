package vn.mobiistar.testversion;

import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MyActivity";
    private static final int PERMISSION_WRITE_EXTERNAL_STORAGE = 0;
    private static JSONObject downloadedFile = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Firebase.setAndroidContext(this);
        FirebaseApp.initializeApp(this);

        Integer permissionCheck = ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        Log.e(TAG, "------======> Quyen ghi du lieu vao external: "+permissionCheck.toString());

        if (ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

            } else {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_WRITE_EXTERNAL_STORAGE);
            }
        } else {
            contactFCM();
        }
        Log.e(TAG, "------======> Hello");

        setContentView(R.layout.firebase);

//        new getSettingKey().execute();

    }

    public void contactFCM(){
        Firebase myFirebaseRef = new Firebase("https://testfcm-7f1a7.firebaseio.com/promotions/0109794100");

//        myFirebaseRef.child("0109794100").setValue("Do you have data? You'll love Firebase.");
        Toast.makeText(getApplicationContext(), "Successfully...", Toast.LENGTH_LONG).show();

        ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Log.e(TAG, dataSnapshot.getValue().toString());
                try{
                    Log.e(TAG, "------======> "+dataSnapshot.child("config").getValue().toString());
                    Map<String, Object> configs = (Map<String, Object>) dataSnapshot.child("config").getValue();
                    Log.e(TAG, "------======> "+configs.toString());
                    Log.e(TAG, "------======> "+configs.get("kind").toString());
                } catch (Exception exx){
                    Log.e(TAG, "------======> "+exx.getMessage());
                }
                downloadedFile = new JSONObject();
//                try{
//                    ArrayList photoList = (ArrayList) dataSnapshot.child("photo").getValue();
//                    Log.e(TAG, photoList.toString());
//                    for(Integer i=0;i<photoList.size(); i++){
//                        String url = photoList.get(i).toString();
//                        Log.e(TAG, url);
////                        downloadFile(url);
//                    }
//                } catch (Exception exx){
//                    Log.e(TAG, exx.getMessage());
//                }
//                try{
//                    ArrayList photoList = (ArrayList) dataSnapshot.child("video").getValue();
//                    Log.e(TAG, photoList.toString());
//                    for(Integer i=0;i<photoList.size(); i++){
//                        String url = photoList.get(i).toString();
//                        Log.e(TAG, url);
////                        downloadFile(url);
//                    }
//                } catch (Exception exx){
//                    Log.e(TAG, exx.getMessage());
//                }
            }

            @Override
            public void onCancelled(FirebaseError databaseError) {
                // Getting Post failed, log a message
                Log.w(TAG, "loadPost:onCancelled", databaseError.toException());
                // ...
            }
        };
        myFirebaseRef.addValueEventListener(postListener);
    }

    public void downloadFile(String url){
        try{
            String promoFolder = "RetailMode";
            File f = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), promoFolder);
            if (!f.exists()) {
                f.mkdirs();
            }
            String filename = url.substring(url.indexOf("promotions"));
            filename = filename.substring(0, filename.indexOf("?"));
            filename = filename.replace("%2F", "");
            filename = filename.replace("promotions", "");
            Log.e(TAG, "------======> Dang download file: "+filename);
            downloadedFile.put(filename, filename);
            Log.e(TAG, "------======> "+downloadedFile.toString());
            FirebaseStorage storage = FirebaseStorage.getInstance();
            StorageReference httpsReference = storage.getReferenceFromUrl(url);
//        String uniqueID = UUID.randomUUID().toString();
            Log.e(TAG, "------======> Duong dan download: "+f.getPath());
            final File localFile = new File(f.getPath()+"/"+filename);
            httpsReference.getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                    // Local temp file has been created
                    Log.e(TAG, "------======> Download thanh cong file: "+localFile.getName());
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {
                    // Handle any errors
                }
            });
        } catch (Exception exx){

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_WRITE_EXTERNAL_STORAGE: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    contactFCM();
                } else {
                    // permission denied, boo! Disable the
                }
                return;
            }
        }
    }

    public class getSettingKey extends AsyncTask<String, Void, String> {

        protected void onPreExecute(){}

        protected String doInBackground(String... arg0) {

            try {

                URL url = new URL("http://retail.tools.mobiistar.com/api/promotions/key"); // here is your URL path

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("imei", "979278258845370");
                postDataParams.put("model", "Mobiistar Prime X1");
                Log.e("params", postDataParams.toString());

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000 /* milliseconds */);
                conn.setConnectTimeout(15000 /* milliseconds */);
                conn.setRequestMethod("GET");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                String request = getPostDataString(postDataParams);
                System.out.print(request);

                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(request);

                writer.flush();
                writer.close();
                os.close();

                int responseCode=conn.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {

                    BufferedReader in=new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuffer sb = new StringBuffer("");
                    String line="";

                    while((line = in.readLine()) != null) { sb.append(line); break; }

                    Log.e("params", sb.toString());

                    in.close();
                    return sb.toString();

                } else {
                    return new String("false : "+responseCode);
                }
            }
            catch(Exception e){
                return new String("Exception: " + e.getMessage());
            }

        }

        @Override
        protected void onPostExecute(String result) {
            Log.d("123", result);
//            TextView hello = (TextView)findViewById(R.id.code_info);
//            hello.setText(result);
            try {
                JSONObject response = new JSONObject(result);
                String key = response.getString("key");
                Toast.makeText(getApplicationContext(), key, Toast.LENGTH_LONG).show();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public String getPostDataString(JSONObject params) throws Exception {

        StringBuilder result = new StringBuilder();
        boolean first = true;

        Iterator<String> itr = params.keys();

        while(itr.hasNext()){

            String key= itr.next();
            Object value = params.get(key);

            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(key, "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(value.toString(), "UTF-8"));

        }
        return params.toString();
//        return result.toString();
    }

}
