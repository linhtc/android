package vn.mobiistar.testversion;

/**
 * Created by linhtc on 23/09/2016.
 */

public class Config {
    public static final String FIREBASE_URL = "https://testfcm-7f1a7.firebaseio.com/";
}
